from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import os
import random
from datetime import datetime
from models import db, User, ChatHistory  # <--- Naya import

app = Flask(__name__)
CORS(app)

# --- Naya Database Configuration ---
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///health_app.db' # SQLite database file ka naam
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Database ko app ke sath joda
db.init_app(app)

# App start hone par database tables create karna
with app.app_context():
    db.create_all()

# --- Configuration ---
UPLOAD_FOLDER = 'static/images'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Iske baad tumhara purana SimpleHealthAI class aur routes waise hi rahenge...

# Ensure upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Simple AI simulation (beginner-friendly, no complex ML)
class SimpleHealthAI:
    def __init__(self):
        # Keywords for pattern matching
        self.stress_keywords =['tired', 'exhausted', 'stressed', 'anxiety', 'cannot sleep', 'no energy']
        self.pain_keywords = ['pain', 'cramps', 'headache', 'back pain', 'stomach pain', 'discomfort']
        self.emotional_keywords = ['sad', 'lonely', 'cry', 'overwhelmed', 'pressure', 'burden']
        self.pcos_keywords = ['irregular periods', 'weight gain', 'acne', 'hair loss', 'facial hair']
        
    def analyze_text(self, text):
        """Analyze text patterns for hidden health issues"""
        text = text.lower()
        score = {
            'stress_level': 0,
            'pain_indicators': 0,
            'emotional_distress': 0,
            'hormonal_risk': 0,
            'urgency': 'low'
        }
        
        # Simple keyword matching
        for keyword in self.stress_keywords:
            if keyword in text:
                score['stress_level'] += 20
                
        for keyword in self.pain_keywords:
            if keyword in text:
                score['pain_indicators'] += 25
                
        for keyword in self.emotional_keywords:
            if keyword in text:
                score['emotional_distress'] += 30
                
        for keyword in self.pcos_keywords:
            if keyword in text:
                score['hormonal_risk'] += 35
        
        # Determine urgency
        total = sum([score['stress_level'], score['pain_indicators'], 
                    score['emotional_distress'], score['hormonal_risk']])
        
        if total > 80:
            score['urgency'] = 'high'
        elif total > 40:
            score['urgency'] = 'medium'
            
        return score
    
    def analyze_voice_tone(self, description):
        """Simulate voice tone analysis"""
        tones = ['calm', 'tired', 'stressed', 'anxious', 'sad']
        # In real app, this would use audio processing
        return {
            'detected_tone': random.choice(tones),
            'confidence': random.randint(70, 95),
            'stress_indicators': random.randint(20, 80)
        }
    
    def analyze_facial_expression(self, image_path):
        """Simulate facial emotion detection"""
        emotions = ['neutral', 'tired', 'stressed', 'sad', 'pain']
        # In real app, this would use OpenCV/FER library
        return {
            'dominant_emotion': random.choice(emotions),
            'pain_detected': random.choice([True, False]),
            'fatigue_level': random.randint(30, 90),
            'confidence': random.randint(75, 98)
        }

# Initialize AI
health_ai = SimpleHealthAI()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    """Smart chatbot endpoint"""
    data = request.json
    user_message = data.get('message', '')
    
    # Analyze the message
    analysis = health_ai.analyze_text(user_message)
    
    # Generate contextual response
    responses = {
        'low': "Thank you for sharing. How long have you been feeling this way?",
        'medium': "I notice you might be experiencing some discomfort. Can you tell me more about your symptoms?",
        'high': "I'm concerned about what you're describing. These symptoms might need attention. Would you like to talk more about this?"
    }
    
    return jsonify({
        'response': responses.get(analysis['urgency'], responses['low']),
        'analysis': analysis,
        'suggestions': generate_suggestions(analysis)
    })

def generate_suggestions(analysis):
    """Generate health suggestions based on analysis"""
    suggestions = []
    if analysis['stress_level'] > 40:
        suggestions.append("🧘 Try deep breathing exercises or meditation")
    if analysis['pain_indicators'] > 40:
        suggestions.append("💊 Consider tracking your pain patterns daily")
    if analysis['emotional_distress'] > 40:
        suggestions.append("💬 Speaking to a counselor might help")
    if analysis['hormonal_risk'] > 40:
        suggestions.append("🏥 A check-up with a gynecologist is recommended")
    
    if not suggestions:
        suggestions.append("✅ Continue monitoring your health daily")
    
    return suggestions

@app.route('/api/analyze-voice', methods=['POST'])
def analyze_voice():
    """Voice tone analysis endpoint"""
    data = request.json
    tone_analysis = health_ai.analyze_voice_tone(data.get('description', ''))
    return jsonify(tone_analysis)

@app.route('/api/analyze-face', methods=['POST'])
def analyze_face():
    """Facial expression analysis endpoint"""
    if 'image' not in request.files:
        return jsonify({'error': 'No image uploaded'}), 400
    
    file = request.files['image']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    # Save uploaded file
    filename = f"face_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)
    
    # Analyze (simulated)
    analysis = health_ai.analyze_facial_expression(filepath)
    analysis['image_url'] = f'/static/images/{filename}'
    
    return jsonify(analysis)

@app.route('/api/silent-check', methods=['GET'])
def silent_check():
    """Silent mode detection - analyze behavior patterns"""
    # Simulate behavior pattern analysis
    return jsonify({
        'silent_mode_active': True,
        'days_since_last_checkin': random.randint(1, 7),
        'behavior_change_detected': random.choice([True, False]),
        'risk_level': random.choice(['low', 'medium', 'high']),
        'message': "We've noticed you haven't checked in recently. Is everything okay?"
    })

@app.route('/api/health-report', methods=['GET'])
def health_report():
    """Generate comprehensive health report"""
    return jsonify({
        'overall_risk': random.choice(['Low', 'Moderate', 'High']),
        'mental_health_score': random.randint(60, 95),
        'physical_health_score': random.randint(65, 90),
        'recommendations': [
            "Schedule regular health checkups",
            "Maintain a symptom diary",
            "Practice self-care routines",
            "Stay connected with support groups"
        ],
        'alert': "Remember: Your health matters. Don't ignore silent symptoms."
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)