// ===== Global Variables =====
const API_BASE_URL = ''; // Empty for same-origin

// ===== Navigation =====
function scrollToSection(sectionId) {
    document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
}

// ===== Voice Analysis =====
async function analyzeVoice() {
    const input = document.getElementById('voiceInput');
    const resultBox = document.getElementById('voiceResult');
    
    if (!input.value.trim()) {
        alert('Please describe how you are feeling first');
        return;
    }
    
    // Show loading
    resultBox.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyzing voice tone...';
    resultBox.classList.remove('hidden');
    
    try {
        const response = await fetch('/api/analyze-voice', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ description: input.value })
        });
        
        const data = await response.json();
        
        resultBox.innerHTML = `
            <h4><i class="fas fa-waveform"></i> Voice Analysis Results</h4>
            <div class="result-item">
                <span>Detected Tone:</span>
                <strong>${data.detected_tone.charAt(0).toUpperCase() + data.detected_tone.slice(1)}</strong>
            </div>
            <div class="result-item">
                <span>Confidence:</span>
                <strong>${data.confidence}%</strong>
            </div>
            <div class="result-item">
                <span>Stress Indicators:</span>
                <strong style="color: ${data.stress_indicators > 60 ? '#f44336' : '#4caf50'}">
                    ${data.stress_indicators}%
                </strong>
            </div>
            <p style="margin-top: 15px; color: #666; font-size: 0.9rem;">
                ${data.stress_indicators > 60 
                    ? '⚠️ High stress detected. Consider taking a break and practicing relaxation techniques.' 
                    : '✅ Stress levels appear normal, but continue monitoring.'}
            </p>
        `;
    } catch (error) {
        resultBox.innerHTML = '<p style="color: red;">Analysis failed. Please try again.</p>';
    }
}

// ===== Facial Expression Analysis =====
function handleImageUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const resultBox = document.getElementById('faceResult');
    resultBox.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyzing facial expressions...';
    resultBox.classList.remove('hidden');
    
    const formData = new FormData();
    formData.append('image', file);
    
    fetch('/api/analyze-face', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        resultBox.innerHTML = `
            <h4><i class="fas fa-face-smile"></i> Facial Analysis Results</h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 15px;">
                <div style="text-align: center;">
                    <img src="${data.image_url}" style="max-width: 100%; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                </div>
                <div>
                    <div class="result-item">
                        <span>Dominant Emotion:</span>
                        <strong>${data.dominant_emotion.charAt(0).toUpperCase() + data.dominant_emotion.slice(1)}</strong>
                    </div>
                    <div class="result-item">
                        <span>Pain Detected:</span>
                        <strong style="color: ${data.pain_detected ? '#f44336' : '#4caf50'}">
                            ${data.pain_detected ? 'Yes ⚠️' : 'No ✓'}
                        </strong>
                    </div>
                    <div class="result-item">
                        <span>Fatigue Level:</span>
                        <strong>${data.fatigue_level}%</strong>
                    </div>
                    <div class="result-item">
                        <span>Confidence:</span>
                        <strong>${data.confidence}%</strong>
                    </div>
                </div>
            </div>
            ${data.pain_detected ? 
                '<p style="background: #ffebee; padding: 10px; border-radius: 8px; color: #c62828; font-size: 0.9rem;">⚠️ Signs of discomfort detected. Consider consulting a healthcare provider if this persists.</p>' 
                : ''}
        `;
    })
    .catch(error => {
        resultBox.innerHTML = '<p style="color: red;">Analysis failed. Please try again.</p>';
    });
}

// ===== Silent Mode Check =====
async function checkSilentMode() {
    try {
        const response = await fetch('/api/silent-check');
        const data = await response.json();
        
        // Update UI
        document.getElementById('lastCheckin').textContent = 
            data.days_since_last_checkin === 1 ? 'Yesterday' : `${data.days_since_last_checkin} days ago`;
        document.getElementById('behaviorChange').textContent = 
            data.behavior_change_detected ? 'Detected ⚠️' : 'Normal';
        document.getElementById('riskLevel').textContent = data.risk_level.toUpperCase();
        
        const riskElement = document.getElementById('riskLevel');
        riskElement.className = 'value ' + (data.risk_level === 'high' ? 'risk-high' : 
                                           data.risk_level === 'medium' ? 'risk-medium' : '');
        
        // Show alert if needed
        if (data.risk_level !== 'low') {
            alert(`Silent Mode Alert: ${data.message}`);
        }
    } catch (error) {
        console.error('Silent check failed:', error);
    }
}

// ===== Chatbot Functions =====
async function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Add user message
    addMessage(message, 'user');
    input.value = '';
    
    // Show typing indicator
    document.getElementById('typingIndicator').classList.remove('hidden');
    
    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: message })
        });
        
        const data = await response.json();
        
        // Hide typing indicator
        document.getElementById('typingIndicator').classList.add('hidden');
        
        // Add bot response
        setTimeout(() => {
            addMessage(data.response, 'bot');
            updateAnalysis(data.analysis);
            showSuggestions(data.suggestions);
        }, 500);
        
    } catch (error) {
        document.getElementById('typingIndicator').classList.add('hidden');
        addMessage('Sorry, I am having trouble connecting. Please try again.', 'bot');
    }
}

function addMessage(text, sender) {
    const container = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    messageDiv.innerHTML = `
        <div class="avatar"><i class="fas fa-${sender === 'user' ? 'user' : 'robot'}"></i></div>
        <div class="text">${text}</div>
    `;
    container.appendChild(messageDiv);
    container.scrollTop = container.scrollHeight;
}

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function quickReply(text) {
    document.getElementById('chatInput').value = text;
    sendMessage();
}

function updateAnalysis(analysis) {
    const panel = document.getElementById('chatAnalysis');
    panel.classList.remove('hidden');
    
    // Animate bars
    setTimeout(() => {
        document.getElementById('stressBar').style.width = analysis.stress_level + '%';
        document.getElementById('painBar').style.width = analysis.pain_indicators + '%';
        document.getElementById('emotionBar').style.width = analysis.emotional_distress + '%';
    }, 100);
}

function showSuggestions(suggestions) {
    if (!suggestions || suggestions.length === 0) return;
    
    const container = document.getElementById('chatMessages');
    const suggestionsDiv = document.createElement('div');
    suggestionsDiv.className = 'message bot';
    suggestionsDiv.innerHTML = `
        <div class="avatar"><i class="fas fa-lightbulb"></i></div>
        <div class="text" style="background: #fff3e0;">
            <strong>Suggestions:</strong><br>
            ${suggestions.map(s => `• ${s}`).join('<br>')}
        </div>
    `;
    container.appendChild(suggestionsDiv);
    container.scrollTop = container.scrollHeight;
}

// ===== Health Report =====
async function generateReport() {
    const reportDiv = document.getElementById('healthReport');
    reportDiv.innerHTML = '<div style="padding: 40px;"><i class="fas fa-spinner fa-spin fa-2x"></i><p>Generating your comprehensive health report...</p></div>';
    reportDiv.classList.remove('hidden');
    
    try {
        const response = await fetch('/api/health-report');
        const data = await response.json();
        
        document.getElementById('reportDate').textContent = new Date().toLocaleDateString();
        document.getElementById('riskBadge').textContent = data.overall_risk + ' Risk';
        document.getElementById('riskBadge').style.background = 
            data.overall_risk === 'High' ? '#f44336' : 
            data.overall_risk === 'Moderate' ? '#ff9800' : '#4caf50';
        
        document.getElementById('mentalScore').textContent = data.mental_health_score;
        document.getElementById('physicalScore').textContent = data.physical_health_score;
        
        const recContainer = document.getElementById('recommendations');
        recContainer.innerHTML = data.recommendations.map(rec => `
            <div class="recommendation-item">
                <i class="fas fa-check-circle" style="color: var(--primary);"></i>
                ${rec}
            </div>
        `).join('');
        
        // Add alert
        recContainer.innerHTML += `
            <div style="margin-top: 20px; padding: 15px; background: #e3f2fd; border-radius: 10px; border-left: 4px solid #2196f3;">
                <i class="fas fa-info-circle" style="color: #2196f3; margin-right: 10px;"></i>
                ${data.alert}
            </div>
        `;
        
    } catch (error) {
        reportDiv.innerHTML = '<p style="color: red; padding: 40px;">Failed to generate report. Please try again.</p>';
    }
}

// ===== Initialize =====
document.addEventListener('DOMContentLoaded', function() {
    // Initial silent check
    checkSilentMode();
    
    // Set up navigation highlighting
    window.addEventListener('scroll', function() {
        const sections = ['home', 'detection', 'chatbot', 'report'];
        const scrollPos = window.scrollY + 100;
        
        sections.forEach(section => {
            const element = document.getElementById(section);
            if (element && element.offsetTop <= scrollPos && (element.offsetTop + element.offsetHeight) > scrollPos) {
                document.querySelectorAll('.nav-links a').forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === '#' + section) {
                        link.classList.add('active');
                    }
                });
            }
        });
    });
});