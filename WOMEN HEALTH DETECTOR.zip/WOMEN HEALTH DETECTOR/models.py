from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

# Database ka instance banaya
db = SQLAlchemy()

# User Table (Future mein login ke liye kaam aayega)
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.String(100), unique=True, nullable=False) # Abhi bina login ke device identify karne ke liye
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # User ke chats se link
    chats = db.relationship('ChatHistory', backref='user', lazy=True)

# Chat History Table (Chatbot ko memory dene ke liye)
class ChatHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user_message = db.Column(db.Text, nullable=False)
    bot_response = db.Column(db.Text, nullable=False)
    stress_level = db.Column(db.Integer, default=0) # AI ka analysis save karne ke liye
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)